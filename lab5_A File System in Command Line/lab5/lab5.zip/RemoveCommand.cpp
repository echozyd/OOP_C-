/*
Author: Jon Shidal
Purpose: CSE 332 lab 5
*/

#include "RemoveCommand.h"
#include "DirectoryFile.h"
#include<iostream>
#include<map>
#include<vector>
#include<sstream>
#include <iterator>

using namespace std;

RemoveCommand::RemoveCommand(AbstractFileSystem* fileSys) : fs(fileSys) {}


void RemoveCommand::delete_r(std::string CWD, std::string filetodelte) {
	string fullpath = CWD + "/" + filetodelte;
	AbstractFile* op = fs->openFile(fullpath);

	// check if non-empty directory file

	if (dynamic_cast<DirectoryFile*> (op) != nullptr && op->getSize() > 0) {
		stringstream ss;
		vector<char> contents = op->read();
		for (int i = 0; i < contents.size(); i++) {
			ss << contents[i];
		}
		vector<string> childs;
		string token;
		while (ss >> token) {
			childs.push_back(token);
		}

		for (auto it = childs.begin(); it != childs.end(); it++) {
			delete_r(fullpath, *it);
		}
	fs->deleteFile(fullpath);

	}
	else {
		fs->deleteFile(fullpath);
		return;
	}

}

// removes a file from the current working directory
int RemoveCommand::execute(std::string& CWD, std::string options) {
	string fullPath = CWD;
	fullPath += '/';
	string true_options;
	auto it = options.find_first_of(" -r");

	// if no "-r"
	if (it == string::npos) {
		true_options = options;
		AbstractFile* op = fs->openFile(fullPath + true_options);

		if (dynamic_cast<DirectoryFile *>(op) != nullptr && op->getSize() > 0) {
			// return some error (can not close non-empty directory whtiouth -r)
			std::cout << "unable to delete non-empty directory";
			return AbstractFileSystem::cantdeletenonemptydirectory;
		}
		else {
			fullPath += true_options;
			int result = fs->deleteFile(fullPath);
			fs->closeFile(op);
			if (result == AbstractFileSystem::filedoesnotexist) {
				cout << "File does not exist" << endl;
				return filedoesnotexist;
			}
			else if (result == AbstractFileSystem::fileisopen) {
				cout << "File is currently in use" << endl;
				return fileinuse;
			}
			return success;
		}
	}
	// with -r recursively delete
	else {
		true_options = options.substr(0, it);
		AbstractFile* op = fs->openFile(fullPath + true_options);

		if(dynamic_cast<DirectoryFile*>(op) != nullptr && op->getSize() > 0) {
			// return some error (can not close non-empty directory whtiouth -r)
			// try to delete the part that could be deleted 
			delete_r(CWD, true_options);
			std::cout << "unable to delete non-empty directory";
			return AbstractFileSystem::cantdeletenonemptydirectory;
		}
		else {
		fullPath += true_options;
		int result = fs->deleteFile(fullPath);
		fs->closeFile(op);
		if (result == AbstractFileSystem::filedoesnotexist) {
			cout << "File does not exist" << endl;
			return filedoesnotexist;
		}
		else if (result == AbstractFileSystem::fileisopen) {
			cout << "File is currently in use" << endl;
			return fileinuse;
		}
		return success;
		}
		
	}

}




void RemoveCommand::displayInfo() {
	cout << "touch removes a file from the file system and then deletes the file" << endl;
	cout << "Usage: rm <filename>" << endl;
}