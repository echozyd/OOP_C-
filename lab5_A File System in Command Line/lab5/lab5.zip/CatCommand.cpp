#include <iostream>

#include "CatCommand.h"
#include "TextFile.h"
#include "ReadFileVisitor.h"
#include <vector>



CatCommand::CatCommand(AbstractFileSystem* fileSys) : fs(fileSys) {}


int CatCommand::execute(std::string & CWD, std::string options) {
	std::string true_file_name;
	auto it = options.find_first_of(" -a");
	std::string full_path;
	if (it == std::string::npos) {
		full_path = CWD + options;
		ReadFileVisitor* visit = new ReadFileVisitor();
		AbstractFile* op = fs->openFile(full_path);
		op->accept(visit);
		delete visit;

		std::cout << "Enetr data you would like to write to the file, enter :wq to save the file and exit, enter :q to exit withough saving" << std::endl;
		std::string line;
		std::cin >> line;
		std::vector<char> to_write;
		while(line != ":wq" && line != ":q"){
			for (auto it = line.begin(); it != line.end(); it++) {
				to_write.push_back(*it);
			}
			std::cin >> line;
		}

		if (line == ":wq") {
			op->write(to_write);
		}
		else if (line == ":q") {
         // do nothing
		}

		return success;
	}
	else {
		true_file_name = options.substr(0, it);
		full_path = CWD + true_file_name;
		ReadFileVisitor* visit = new ReadFileVisitor();
		AbstractFile* op = fs->openFile(full_path);
		op->accept(visit);
		delete visit;

		std::cout << "Enetr data you would like to add to the file, enter :wq to save the file and exit, enter :q to exit withough saving" << std::endl;
		std::string line;
		std::cin >> line;
		std::vector<char> to_append;
		while (line != ":wq" && line != ":q") {
			for (auto it = line.begin(); it != line.end(); it++) {
				to_append.push_back(*it);
			}
			std::cin >> line;
		}

		if (line == ":wq") {
			op->append(to_append);
		}
		else if (line == ":q") {
			// do nothing
		}
	}

}



void CatCommand::displayInfo() {
	std::cout << "cat write or append contents to target file" << std::endl;
	std::cout << "Usage: cat <filename>" << "with option -a for append and nonting for write" << std::endl;
}
