#pragma once

#include "AbstractFile.h"



class ProxyFile : public AbstractFile {
public:
	ProxyFile();
	ProxyFile(AbstractFile* file);
	void request();
private:
	unsigned int link_count;
	AbstractFile* content;

};
